package com.example.zumi;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txt_id,txt_id2,txt_id3;
    Boolean isCheck=false;
    CheckBox cb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        txt_id= (TextView)findViewById(R.id.txt_id);
        txt_id2=(TextView)findViewById(R.id.textView3);
        txt_id3=(TextView)findViewById(R.id.textView4);
        txt_id3.setVisibility(View.INVISIBLE);
        txt_id.setText("I agree to OneScore's Terms of Use and Privacy Policy and authorise to communicate via SMS, Email and Whatsapp. I hearby request for a copy of my Credit Information and/or aggregate on my registered email id or through my OneScore account, and authorise Experian and CIBIL to also provide the same to FPL Technologies Private Limited, on my behalf.");
        txt_id2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isCheck) {
                    txt_id.setMaxLines(10);
                    isCheck = false;
                } else {
                    txt_id.setMaxLines(2);
                    isCheck = true;
                    txt_id2.setVisibility(View.INVISIBLE);
                    txt_id3.setVisibility(View.VISIBLE);
                    txt_id3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            txt_id.setMaxLines(10);
                            isCheck = false;
                            txt_id3.setVisibility(View.INVISIBLE);
                            txt_id2.setVisibility(View.VISIBLE);
                        }
                    });
                }
            }
        });
    }
}